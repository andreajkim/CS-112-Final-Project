# CS-112-Final-Project
2018 Spring Semester 

Group members: Martin Glusker, Fengling Hu, Andrea Kim

To run: Run Main method to open applet. Click Open Files and choose a directory with at least one mp3 file in it. Play/pause, shuffle, repeat once, previous, and next buttons have functionality. Other buttons do not yet. Will bug out in many cases (eg if you press "next" when there is no next song.) These bugs will be fixed.