# CS-112-Final-Project
2018 Spring Semester 

Group members: Fengling Hu, Martin Glusker, Andrea Kim, Caled Winfrey

To compile: You will need to install JavaZoom (included as jl1.0.1.jar) into your Java Extensions folder. This jar file contains .class files.

To run: Run Main method to open applet. Click Open Music and choose a directory with at least one mp3 file in it (one mp3 is included in the zip). Play/pause, shuffle, repeat once, previous, and next buttons have functionality. Other buttons do not yet.

Resources used: CustomPlayer.java is essentially copied from StackOverflow (credited in comments). All other code was written.